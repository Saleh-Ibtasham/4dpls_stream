# Master-PanopticSegmentationAugmentation-Wangkang

This is repository includes Python3 scripts for data conversion, data augmentation and 4DPLS model during degree project "Point Cloud Data Augmentation for 4D Panoptic Segmentation".  



### Overview of files

* __geo.py__:  Script to do geometric augmentation for point cloud data 
* __pcd2bin.py__: Script to convert .pcd format to .bin format
* __4D-PLS__: folder where the 4dpls model is built

### Authors

Wangkang Jin

